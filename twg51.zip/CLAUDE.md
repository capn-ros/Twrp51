# CLAUDE.md — TWG51 (TWRP para Moto G51 5G, cypfq)

**Creado por Andrés Londero.** Todo en castellano (código comentado, docs, mensajes).

## Qué es
TWRP para el Motorola Moto G51 5G (`cypfq`, SM4350 "holi", kernel 5.4, A/B, recovery dentro de
`boot`, header v3 con `vendor_boot`, particiones dinámicas Virtual A/B). Teléfono de Andrés:
**XT2171-1, canal RETAR, Android 12, compilación S2RYA32.58-13-12-5-6-1**
(firmware ya cargado en `config/firmware.conf`). Se compila en GitHub Actions al subir `twg51.zip`.

## Reglas del proyecto
- **No cambiar la interfaz** (tema, idioma por defecto, textos que se ven en pantalla, nombre
  de versión mostrado) sin consultarlo antes con Andrés.
- Al terminar cada etapa, dejar todo documentado dentro del zip: este archivo, `docs/`,
  `README.md`, pruebas y comentarios.
- El kernel debe salir del **mismo firmware** que tiene el teléfono (los módulos dependen de eso).
- No se puede probar en el dispositivo desde acá: cada cambio se valida con
  `fastboot boot` siguiendo `docs/PRUEBAS-EN-EL-TELEFONO.md`.

## Decisiones tomadas
- Base: árbol de twrpdtgen (firmware A11) adaptado a **twrp-12.1** con manifiesto mínimo.
- El árbol se completa en el workflow con `scripts/preparar_arbol.py` desde el firmware de stock:
  kernel → `prebuilt/kernel`; módulos táctiles + dependencias → `recovery/root/system/etc/twg51/modulos/`
  con `orden.txt`; firmware táctil → `recovery/root/vendor/firmware/`; fstab de stock filtrado
  (sin flags AVB) → `recovery/root/system/etc/recovery.fstab`; `generated/info.mk`.
- Los módulos los carga `twg51_modulos.sh` (exec desde `init.recovery.cypfq.rc`, `on init`), no
  `TW_LOAD_VENDOR_MODULES`: así no se pisa `/lib/modules/modules.dep` del vendor_boot.
- Workflow en dos jobs: `preparar` (firmware, ~15 GB en /mnt) y `compilar` (TWRP, en /mnt).

## Estado
- Fase 1 armada, **sin compilar ni probar todavía** (2026-11-15).
- Firmware exacto cargado (RETAR S2RYA32.58-13-12-5-6-1).
- Pendiente: que Andrés suba el zip, compile, pruebe con `fastboot boot` y mande logs.
- Fases siguientes en `docs/FASES.md` (descifrado, bootctrl, OrangeFox).

## Comandos
- Pruebas: `python3 -m unittest discover -s tests -v`
- Sintaxis de scripts: `bash -n scripts/*.sh device/motorola/cypfq/recovery/root/system/bin/*.sh`
